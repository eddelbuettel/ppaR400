#!/usr/bin/env r
cat(search(),"\n")
stop("FOO")
cat(ls("Autoloads"))
