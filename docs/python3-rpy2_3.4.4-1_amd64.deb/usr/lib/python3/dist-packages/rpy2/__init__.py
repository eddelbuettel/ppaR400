__version_vector__ = (3, 4, 4)

__version__ = '.'.join(str(x) for x in __version_vector__)
